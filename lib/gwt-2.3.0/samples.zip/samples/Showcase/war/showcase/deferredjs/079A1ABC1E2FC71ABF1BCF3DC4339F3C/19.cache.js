function a4(){}
function X3(){}
function Exb(){}
function Vxb(){}
function Ixb(){}
function KYb(){}
function JYb(){}
function Bxb(b){Thb(b.c,wxb(b.b))}
function iyb(){iyb=_wc;Txb=new tgb(oGc,1,1)}
function ayb(){ayb=_wc;Lxb=new tgb(gGc,15,16)}
function cyb(){cyb=_wc;Nxb=new tgb(iGc,16,16)}
function eyb(){eyb=_wc;Pxb=new tgb(kGc,16,16)}
function fyb(){fyb=_wc;Qxb=new tgb(lGc,16,16)}
function gyb(){gyb=_wc;Rxb=new tgb(mGc,16,16)}
function hyb(){hyb=_wc;Sxb=new tgb(nGc,16,16)}
function jyb(){jyb=_wc;Uxb=new tgb(pGc,16,16)}
function byb(){byb=_wc;Mxb=new tgb(hGc,32,32)}
function dyb(){dyb=_wc;Oxb=new tgb(jGc,32,32)}
function $xb(){$xb=_wc;Jxb=new tgb(eGc,32,32)}
function _xb(){_xb=_wc;Kxb=new tgb(fGc,32,32)}
function LYb(b,c,d){NYb(b,c,b.k.d);QYb(b,b.k.d-1,d)}
function sxb(b,c,d){Acc(b,Aec(new Bec(c.e,c.c,c.d,c.f,c.b))+Kxc+d)}
function Fxb(b,c,d,e,f){this.c=b;this.e=c;this.b=d;this.d=e;this.f=f}
function aZb(b){var c,d,e;c=fk(b);e=TUb(c,1);d=TUb(e,1);return fk(d)}
function _3(){var b;while(Y3){b=Y3;Y3=Y3.c;!Y3&&(Z3=null);Bxb(b.b)}}
function $Yb(){$Yb=_wc;ZYb=iI(K_,{17:1,49:1},1,['stackItemTop','stackItemMiddle'])}
function SYb(b,c){if(c>=b.k.d||c<0||c==b.c){return}b.c>=0&&RYb(b,b.c,false);b.c=c;RYb(b,b.c,true)}
function QYb(b,c,d){var e,f;if(c>=b.k.d){return}f=TUb(TUb(b.b,c*2),0);e=fk(f);aZb(e).innerHTML=d||zxc}
function TYb(b,c){var d,e,f,g;for(g=c,d=b.k.d;g<d;++g){f=TUb(b.b,g*2);e=fk(f);e[yGc]=g;c==0?Ud(e,DGc,true):Ud(e,DGc,false)}}
function uxb(b){var c,d,e,f,g;g=new Tdc;g.f[ABc]=4;for(d=wjb(b.b),e=0,f=d.length;e<f;++e){c=d[e];Rdc(g,new UWb(c))}return g}
function xjb(b){var c,d;c=qI(b.b.$c(xGc),49);if(c==null){d=iI(K_,{17:1,49:1},1,[SFc,TFc,UFc,VFc,WFc]);b.b.ad(xGc,d);return d}else{return c}}
function wjb(b){var c,d;c=qI(b.b.$c(wGc),49);if(c==null){d=iI(K_,{17:1,49:1},1,[LFc,MFc,NFc,OFc,PFc,QFc]);b.b.ad(wGc,d);return d}else{return c}}
function ujb(b){var c,d;c=qI(b.b.$c(uGc),49);if(c==null){d=iI(K_,{17:1,49:1},1,[tFc,uFc,vFc,wFc,xFc,yFc,zFc,AFc]);b.b.ad(uGc,d);return d}else{return c}}
function vjb(b){var c,d;c=qI(b.b.$c(vGc),49);if(c==null){d=iI(K_,{17:1,49:1},1,[CFc,DFc,EFc,FFc,GFc,HFc,IFc,JFc]);b.b.ad(vGc,d);return d}else{return c}}
function c4(){$3=new a4;di((bi(),ai),19);!!$stats&&$stats(Ki(tGc,Dxc,-1,-1));$3.Dd();!!$stats&&$stats(Ki(tGc,VCc,-1,-1))}
function PYb(b,c,d){var e,f,g;e=JVb(b,c);if(e){f=2*d;g=TUb(b.b,f);b.b.removeChild(g);g=TUb(b.b,f);b.b.removeChild(g);b.c==d?(b.c=-1):b.c>d&&--b.c;TYb(b,d)}return e}
function MYb(b,c){var d,e;while(!!c&&c!=b.N){d=c[yGc]==null?null:String(c[yGc]);if(d!=null){e=parseInt(c[zGc])||0;return e==(b.$H||(b.$H=++Mi))?Glc(d):-1}c=hk(c)}return -1}
function OYb(b,c){var d,e,f,g,i;qdc(b.N,zxc,c);g=UUb(b.b)>>1;for(f=0;f<g;++f){i=fk(TUb(b.b,2*f));e=fk(i);d=fk(TUb(b.b,2*f+1));qdc(i,c,'text-wrapper'+f);qdc(d,c,BGc+f);qdc(b.jf(e),c,CGc+f)}}
function _Yb(){var b,c,d;c=$doc.createElement(_Ac);d=$doc.createElement(aBc);c.appendChild(d);c.style[Pyc]=PDc;c[ABc]=0;c[BBc]=0;for(b=0;b<ZYb.length;++b){d.appendChild(kZb(ZYb[b]))}return c}
function vxb(b,c){var d,e,f;d=new Z1b;d.f[ABc]=0;d.d=(R1b(),P1b);W1b(d,new hSb(c));e=new YZb(b);e.N[uxc]=XFc;f=X1b(d);d.c.appendChild(f);fe(e);Ydc(d.k,e);f.appendChild(e.N);he(e,d);return xk(d.N)}
function RYb(b,c,d){var e,f,g,i,j;g=TUb(b.b,c*2);if(!g){return}e=fk(g);Ud(e,'gwt-StackPanelItem-selected',d);j=TUb(b.b,c*2+1);j.style.display=d?zxc:Oyc;Zdc(b.k,c).xb(d);i=TUb(b.b,(c+1)*2);if(i){f=fk(i);Ud(f,'gwt-StackPanelItem-below-selected',d)}}
function bZb(){var b;$Yb();this.k=new cec(this);b=$doc.createElement(_Ac);this.N=b;this.b=$doc.createElement(aBc);b.appendChild(this.b);b[ABc]=0;b[BBc]=0;KUb();YUb(b,1);1&131072&&b.addEventListener(LAc,PUb,false);this.N[uxc]='gwt-StackPanel';Vd(this.N,'gwt-DecoratedStackPanel')}
function txb(b){var c,d,e,f,g,i,j,k,n,o,p;k=new Z1b;k.f[ABc]=5;W1b(k,new hSb((_xb(),Kxb)));e=new WZb;p=X1b(k);k.c.appendChild(p);fe(e);Ydc(k.k,e);p.appendChild(e.N);he(e,k);j=new $e(true,false);j.Ob(k);n=new Tdc;n.f[ABc]=4;i=ujb(b.b);d=vjb(b.b);for(o=0;o<i.length;++o){g=i[o];c=d[o];f=new lWb(g);Rdc(n,f);$d(f,new Fxb(e,g,c,f,j),(so(),so(),ro))}return n}
function wxb(b){var c,d,e,f,g,i,j,k;e=new Vxb;g=new bZb;g.N.style[Pyc]=YFc;f=vxb($Fc,(dyb(),Oxb));LYb(g,(j=new dcc(e),k=Acc(j.j,_Fc),i=xjb(b.b),sxb(k,(cyb(),Nxb),i[0]),sxb(k,(ayb(),Lxb),i[1]),sxb(k,(fyb(),Qxb),i[2]),sxb(k,(eyb(),Pxb),i[3]),sxb(k,(gyb(),Rxb),i[4]),Kcc(k,true,true),j),f);d=vxb(aGc,(byb(),Mxb));LYb(g,uxb(b),d);c=vxb(bGc,($xb(),Jxb));LYb(g,txb(b),c);OYb(g,'cwStackPanel');return g}
function NYb(b,c,d){var e,f,g,i,j;j=$doc.createElement(xBc);g=$doc.createElement(yBc);j.appendChild(g);g.appendChild(_Yb());i=$doc.createElement(xBc);f=$doc.createElement(yBc);i.appendChild(f);d=EVb(b,c,d);e=d*2;XUb(b.b,i,e);XUb(b.b,j,e);Ud(g,'gwt-StackPanelItem',true);g[zGc]=b.$H||(b.$H=++Mi);g[Qyc]=$Cc;Ud(f,'gwt-StackPanelContent',true);f[Qyc]=PDc;f[AGc]=Iyc;HVb(b,c,f,d,false);TYb(b,d);if(b.c==-1){SYb(b,0)}else{RYb(b,d,false);b.c>=d&&++b.c;RYb(b,b.c,true)}}
var yGc='__index',zGc='__owner',uGc='cwStackPanelContacts',vGc='cwStackPanelContactsEmails',wGc='cwStackPanelFilters',xGc='cwStackPanelMailFolders',DGc='gwt-StackPanelItem-first',tGc='runCallbacks19';_=a4.prototype=X3.prototype=new Z;_.gC=function b4(){return ZM};_.Dd=function f4(){_3()};_.cM={};_=Fxb.prototype=Exb.prototype=new Z;_.gC=function Gxb(){return gS};_.jc=function Hxb(b){var c,d;i$b(this.c.b,this.e+cGc+this.b+dGc,true);c=nk(this.d.N)+14;d=pk(this.d.N)+14;Te(this.f,c,d);this.f.Rb()};_.cM={25:1,140:1};_.b=null;_.c=null;_.d=null;_.e=null;_.f=null;_=Vxb.prototype=Ixb.prototype=new Z;_.gC=function Wxb(){return hS};_.Vd=function Xxb(){return hyb(),Sxb};_.Ud=function Yxb(){return iyb(),Txb};_.Wd=function Zxb(){return jyb(),Uxb};_.cM={};var Jxb=null,Kxb=null,Lxb=null,Mxb=null,Nxb=null,Oxb=null,Pxb=null,Qxb=null,Rxb=null,Sxb=null,Txb=null,Uxb=null;_=KYb.prototype=new CVb;_.gC=function UYb(){return _X};_.jf=function VYb(b){return b};_.Eb=function WYb(b){var c,d;if(JUb(b.type)==1){d=b.target;c=MYb(this,d);c!=-1&&SYb(this,c)}de(this,b)};_.ub=function XYb(b){OYb(this,b)};_.Kb=function YYb(b){return PYb(this,b,$dc(this.k,b))};_.cM={13:1,14:1,15:1,16:1,69:1,71:1,131:1};_.b=null;_.c=-1;_=bZb.prototype=JYb.prototype=new KYb;_.gC=function cZb(){return aW};_.jf=function dZb(b){return aZb(b)};_.cM={13:1,14:1,15:1,16:1,69:1,71:1,131:1};var ZYb;var ZM=ulc(wCc,'AsyncLoader19'),gS=ulc(DCc,'CwStackPanel$2'),hS=ulc(DCc,'CwStackPanel_Images_ar_InlineClientBundleGenerator'),_X=ulc(fCc,'StackPanel'),aW=ulc(fCc,'DecoratedStackPanel');sxc(c4)();