function Qcb(){}
function Lcb(){}
function AEb(){}
function g0b(){}
function BEb(b){this.b=b}
function h0b(){var b;this.N=(b=$doc.createElement(bBc),b.type='file',b);this.N[uxc]='gwt-FileUpload'}
function Scb(){Ocb=new Qcb;di((bi(),ai),43);!!$stats&&$stats(Ki(GIc,Dxc,-1,-1));Ocb.Dd();!!$stats&&$stats(Ki(GIc,VCc,-1,-1))}
function Pcb(){var b,c,d,e;while(Mcb){b=Mcb;Mcb=Mcb.c;!Mcb&&(Ncb=null);Thb(b.b.b,(e=new Tdc,Rdc(e,new YZb('<b>\u0642\u0645 \u0628\u0627\u062E\u062A\u064A\u0627\u0631 \u0645\u0644\u0641:<\/b>')),c=new h0b,qdc(c.N,zxc,'cwFileUpload'),Rdc(e,c),d=new IWb('\u062A\u0635\u0639\u064A\u062F \u0627\u0644\u0645\u0644\u0641'),$d(d,new BEb(c),(so(),so(),ro)),Rdc(e,new YZb('<br>')),Rdc(e,d),e))}}
var GIc='runCallbacks43';_=Qcb.prototype=Lcb.prototype=new Z;_.gC=function Rcb(){return wO};_.Dd=function Vcb(){Pcb()};_.cM={};_=BEb.prototype=AEb.prototype=new Z;_.gC=function CEb(){return yT};_.jc=function DEb(b){var c;c=this.b.N.value;c.length==0?($wnd.alert('\u064A\u062C\u0628 \u0639\u0644\u064A\u0643 \u0627\u062E\u062A\u064A\u0627\u0631 \u0645\u0644\u0641 \u0644\u0644\u062A\u0635\u0639\u064A\u062F'),undefined):($wnd.alert('\u062A\u0645 \u062A\u0635\u0639\u064A\u062F \u0627\u0644\u0645\u0644\u0641!'),undefined)};_.cM={25:1,140:1};_.b=null;_=h0b.prototype=g0b.prototype=new Dd;_.gC=function i0b(){return uW};_.Eb=function j0b(b){de(this,b)};_.cM={13:1,14:1,15:1,16:1,69:1,71:1};var wO=ulc(wCc,'AsyncLoader43'),yT=ulc(JCc,'CwFileUpload$1'),uW=ulc(fCc,'FileUpload');sxc(Scb)();