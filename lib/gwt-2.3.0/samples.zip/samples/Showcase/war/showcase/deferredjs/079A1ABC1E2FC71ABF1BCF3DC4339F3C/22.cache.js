function s5(){}
function n5(){}
function Ryb(){}
function Vyb(){}
function Zyb(){}
function Syb(b){this.b=b}
function Wyb(b){this.b=b}
function bzb(b){this.b=b}
function Oyb(b){Thb(b.c,Jyb(b.b))}
function r5(){var b;while(o5){b=o5;o5=o5.c;!o5&&(p5=null);Oyb(b.b)}}
function $yb(b){_yb(b,(1+Math.cos(6.283185307179586))/2);b.b.j.N[gDc]=!true;b.b.i.N[gDc]=!false}
function u5(){q5=new s5;di((bi(),ai),22);!!$stats&&$stats(Ki(aHc,Dxc,-1,-1));q5.Dd();!!$stats&&$stats(Ki(aHc,VCc,-1,-1))}
function _yb(b,c){var d;d=6.283185307179586*c;azb(b,b.b.d,d,0);azb(b,b.b.c,d,1.5707963267948966);azb(b,b.b.e,d,3.141592653589793);azb(b,b.b.f,d,4.71238898038469)}
function azb(b,c,d,e){var f,g;d+=e;f=100*Math.cos(d)+120;g=100*Math.sin(d)+120;TVb(b.b.b,c,~~Math.max(Math.min(f,2147483647),-2147483648),~~Math.max(Math.min(g,2147483647),-2147483648))}
function Jyb(b){var c,d,e,f,g,i;b.b=new VVb;Id(b.b,bHc,bHc);b.b.ub(cHc);b.f=new hSb(($jb(),Ojb));b.c=new hSb(Ojb);b.d=new hSb(Ojb);b.e=new hSb(Ojb);NVb(b.b,b.f);NVb(b.b,b.c);NVb(b.b,b.d);NVb(b.b,b.e);c=new hZb;ze(c,b.b);e=new hZb;ze(e,(f=new Tdc,f.f[ABc]=5,f.b=(I1b(),C1b),Rdc(f,new YZb('<b>\u062E\u064A\u0627\u0631\u0627\u062A \u0627\u0644\u0631\u0633\u0648\u0645 \u0627\u0644\u0645\u062A\u062D\u0631\u0643\u0629<\/b>')),b.j=new IWb('\u0627\u0644\u0628\u062F\u0621'),Ud(b.j.tb(),dHc,true),$d(b.j,new Syb(b),(so(),so(),ro)),Rdc(f,b.j),b.i=new IWb('\u0625\u0644\u063A\u0627\u0621'),Ud(b.i.tb(),dHc,true),$d(b.i,new Wyb(b),ro),Rdc(f,b.i),f));d=new Z1b;d.f[ABc]=10;g=X1b(d);d.c.appendChild(g);fe(e);Ydc(d.k,e);g.appendChild(e.N);he(e,d);i=X1b(d);d.c.appendChild(i);fe(c);Ydc(d.k,c);i.appendChild(c.N);he(c,d);b.g=new bzb(b);$yb(b.g);return d}
var aHc='runCallbacks22';_=s5.prototype=n5.prototype=new Z;_.gC=function t5(){return jN};_.Dd=function x5(){r5()};_.cM={};_=Syb.prototype=Ryb.prototype=new Z;_.gC=function Tyb(){return pS};_.jc=function Uyb(b){gb(this.b.g,2000,(new Date).getTime())};_.cM={25:1,140:1};_.b=null;_=Wyb.prototype=Vyb.prototype=new Z;_.gC=function Xyb(){return qS};_.jc=function Yyb(b){fb(this.b.g)};_.cM={25:1,140:1};_.b=null;_=bzb.prototype=Zyb.prototype=new Y;_.gC=function czb(){return rS};_.$=function dzb(){$yb(this)};_._=function ezb(){var b;b=6.283185307179586*((1+Math.cos(3.141592653589793))/2);azb(this,this.b.d,b,0);azb(this,this.b.c,b,1.5707963267948966);azb(this,this.b.e,b,3.141592653589793);azb(this,this.b.f,b,4.71238898038469);this.b.j.N[gDc]=!false;this.b.i.N[gDc]=!true};_.ab=function fzb(b){_yb(this,b)};_.cM={52:1};_.b=null;var jN=ulc(wCc,'AsyncLoader22'),pS=ulc(ECc,'CwAnimation$2'),qS=ulc(ECc,'CwAnimation$3'),rS=ulc(ECc,'CwAnimation$CustomAnimation');sxc(u5)();