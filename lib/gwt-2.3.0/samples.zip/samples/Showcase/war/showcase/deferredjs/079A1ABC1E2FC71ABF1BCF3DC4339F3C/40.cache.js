function Qbb(){}
function Lbb(){}
function VDb(){}
function UDb(){}
function Sbb(){Obb=new Qbb;di((bi(),ai),40);!!$stats&&$stats(Ki(CIc,Dxc,-1,-1));Obb.Dd();!!$stats&&$stats(Ki(CIc,VCc,-1,-1))}
function Pbb(){var b,c,d,e,f,g;while(Mbb){b=Mbb;Mbb=Mbb.c;!Mbb&&(Nbb=null);Thb(b.b.b,(d=new Z1b,d.f[ABc]=10,e=new JWb('\u0632\u0631 \u0639\u0627\u062F\u064A',new VDb),qdc(e.N,zxc,'cwBasicButton-normal'),f=X1b(d),d.c.appendChild(f),fe(e),Ydc(d.k,e),f.appendChild(e.N),he(e,d),c=new IWb('\u0632\u0631 \u0627\u0644\u0645\u0639\u0648\u0642\u064A\u0646'),qdc(c.N,zxc,'cwBasicButton-disabled'),c.N[gDc]=true,g=X1b(d),d.c.appendChild(g),fe(c),Ydc(d.k,c),g.appendChild(c.N),he(c,d),d))}}
var CIc='runCallbacks40';_=Qbb.prototype=Lbb.prototype=new Z;_.gC=function Rbb(){return nO};_.Dd=function Vbb(){Pbb()};_.cM={};_=VDb.prototype=UDb.prototype=new Z;_.gC=function WDb(){return pT};_.jc=function XDb(b){$wnd.alert('\u062A\u0648\u0642\u0641 \u0639\u0646 \u0648\u0643\u0632\u064A!')};_.cM={25:1,140:1};var nO=ulc(wCc,'AsyncLoader40'),pT=ulc(JCc,'CwBasicButton$1');sxc(Sbb)();