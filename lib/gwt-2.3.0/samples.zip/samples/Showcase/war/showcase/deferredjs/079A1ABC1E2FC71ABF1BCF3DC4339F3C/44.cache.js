function gdb(){}
function bdb(){}
function b2b(){}
function c2b(){c2b=_wc;g$b()}
function bUb(b){$Tb();!!ZTb&&lVb(ZTb,b)}
function d2b(b,c){qdc(b.b,zxc,c);qdc(b.N,c,IIc)}
function e2b(b,c){c2b();f2b.call(this,$doc.createElement(xxc));i$b(this.c,b,false);this.d=c;this.b[sHc]=dyc+c}
function IEb(b,c){var d,e;d=new e2b(c,(e=b.d,e=Kmc(e,e.lastIndexOf(Tmc(46))+1),hzc+e));d2b(d,'cwHyperlink-'+b.d);return d}
function idb(){edb=new gdb;di((bi(),ai),44);!!$stats&&$stats(Ki(HIc,Dxc,-1,-1));edb.Dd();!!$stats&&$stats(Ki(HIc,VCc,-1,-1))}
function f2b(b){this.b=$doc.createElement(uAc);if(!b){this.N=this.b}else{this.N=b;this.N.appendChild(this.b)}this.J==-1?$Ub(this.N,1|(this.N.__eventBits||0)):(this.J|=1);this.N[uxc]='gwt-Hyperlink';this.c=new k$b(this.b,true)}
function fdb(){var b,c;while(cdb){b=cdb;cdb=cdb.c;!cdb&&(ddb=null);Thb(b.b.b,(c=new Tdc,Rdc(c,new YZb('<b>\u0627\u062E\u062A\u064A\u0627\u0631 \u0627\u062D\u062F \u0627\u0644\u0627\u0642\u0633\u0627\u0645:<\/b>')),c.f[ABc]=5,Rdc(c,IEb(sT,Wzc)),Rdc(c,IEb(ET,$zc)),Rdc(c,IEb(rT,Uzc)),Rdc(c,IEb(uT,Xzc)),Rdc(c,IEb(AT,Zzc)),Rdc(c,IEb(xT,Yzc)),c))}}
var HIc='runCallbacks44',IIc='wrapper';_=gdb.prototype=bdb.prototype=new Z;_.gC=function hdb(){return zO};_.Dd=function ldb(){fdb()};_.cM={};_=e2b.prototype=b2b.prototype=new Dd;_.gC=function g2b(){return LW};_.Eb=function h2b(b){var c,d,e,f,g,i,j,k;de(this,b);if(JUb(b.type)==1&&(i=lk(b),c=!!b.altKey,d=!!b.ctrlKey,e=!!b.metaKey,k=!!b.shiftKey,g=c||d||e||k,f=i==4,j=i==2,!g&&!f&&!j)){bUb(this.d);b.preventDefault()}};_.ub=function i2b(b){qdc(this.b,zxc,b);qdc(this.N,b,IIc)};_.cM={13:1,14:1,15:1,16:1,69:1,71:1};_.c=null;_.d=null;var zO=ulc(wCc,'AsyncLoader44'),LW=ulc(fCc,'Hyperlink');sxc(idb)();