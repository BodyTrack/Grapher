function yab(){}
function tab(){}
function xab(){var b;while(uab){b=uab;uab=uab.c;!uab&&(vab=null);Thb(b.b.b,oCb())}}
function Aab(){wab=new yab;di((bi(),ai),37);!!$stats&&$stats(Ki(VHc,Dxc,-1,-1));wab.Dd();!!$stats&&$stats(Ki(VHc,VCc,-1,-1))}
function oCb(){var b,c,d,e,f;c=new b1b(4,4);e=c.i;d=c.g;for(f=0;f<e;++f){for(b=0;b<d;++b){v0b(c,f,b,new hSb((Zjb(),Njb)))}}q0b(c,'cwGrid');return c}
var VHc='runCallbacks37';_=yab.prototype=tab.prototype=new Z;_.gC=function zab(){return bO};_.Dd=function Dab(){xab()};_.cM={};var bO=ulc(wCc,'AsyncLoader37');sxc(Aab)();