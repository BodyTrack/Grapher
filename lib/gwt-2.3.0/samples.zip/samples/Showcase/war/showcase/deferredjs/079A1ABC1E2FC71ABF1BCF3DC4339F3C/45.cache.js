function ydb(){}
function tdb(){}
function VEb(b){Thb(b.c,QEb(b.b))}
function xdb(){var b;while(udb){b=udb;udb=udb.c;!udb&&(vdb=null);VEb(b.b)}}
function Adb(){wdb=new ydb;di((bi(),ai),45);!!$stats&&$stats(Ki(JIc,Dxc,-1,-1));wdb.Dd();!!$stats&&$stats(Ki(JIc,VCc,-1,-1))}
function pjb(b){var c,d;c=qI(b.b.$c(LIc),49);if(c==null){d=iI(K_,{17:1,49:1},1,[_Ec,aFc,bFc,cFc,dFc,'\u0643\u0631\u0629 \u0627\u0644\u0645\u0627\u0621']);b.b.ad(LIc,d);return d}else{return c}}
function ojb(b){var c,d;c=qI(b.b.$c(KIc),49);if(c==null){d=iI(K_,{17:1,49:1},1,['\u0627\u0632\u0631\u0642','\u0627\u062D\u0645\u0631','\u0627\u0635\u0641\u0631','\u0627\u062E\u0636\u0631']);b.b.ad(KIc,d);return d}else{return c}}
function QEb(b){var c,d,e,f,g,i,j;j=new Tdc;Rdc(j,new YZb('<b>\u0627\u062E\u062A\u0631 \u0627\u0644\u0644\u0648\u0646 \u0627\u0644\u0645\u0641\u0636\u0644 \u0644\u062F\u064A\u0643:<\/b>'));d=ojb(b.b);for(e=0;e<d.length;++e){c=d[e];f=new t6b(Kzc,c);SWb(f,'cwRadioButton-color-'+c);e==2&&(f.d.disabled=true,Kd(f,Qd(f.N)+Vzc,true));Rdc(j,f)}Rdc(j,new YZb('<br><b>\u0627\u062E\u062A\u0631 \u0627\u0644\u0631\u064A\u0627\u0636\u0629 \u0627\u0644\u0645\u0641\u0636\u0644\u0629 \u0644\u062F\u064A\u0643:<\/b>'));i=pjb(b.b);for(e=0;e<i.length;++e){g=i[e];f=new t6b('sport',g);SWb(f,'cwRadioButton-sport-'+Hmc(g,Kxc,zxc));e==2&&TWb(f,(_kc(),_kc(),$kc));Rdc(j,f)}return j}
var KIc='cwRadioButtonColors',LIc='cwRadioButtonSports',JIc='runCallbacks45';_=ydb.prototype=tdb.prototype=new Z;_.gC=function zdb(){return CO};_.Dd=function Ddb(){xdb()};_.cM={};var CO=ulc(wCc,'AsyncLoader45');sxc(Adb)();