function yH(){}
function tH(){}
function Qab(){}
function Lab(){}
function L4b(){}
function ECb(){}
function ICb(){}
function xH(){xH=_wc;wH=new yH}
function FCb(b,c){this.c=b;this.b=c}
function JCb(b,c){this.c=b;this.b=c}
function jfc(c){try{return c.selectionStart}catch(b){return 0}}
function kfc(c){try{return c.selectionEnd-c.selectionStart}catch(b){return 0}}
function xCb(b,c){i$b(c.b,'\u0645\u062E\u062A\u0627\u0631\u0629: '+b.pf()+kyc+b.qf(),false)}
function Sab(){Oab=new Qab;di((bi(),ai),38);!!$stats&&$stats(Ki(XHc,Dxc,-1,-1));Oab.Dd();!!$stats&&$stats(Ki(XHc,VCc,-1,-1))}
function b5b(){var b;Z4b();S4b.call(this,(b=$doc.createElement(bBc),b.type='password',b),(!hFb&&(hFb=new iFb),!dFb&&(dFb=new eFb)));this.N[uxc]='gwt-PasswordTextBox'}
function wCb(b,c){var d,e,f,g;d=new Z1b;d.f[ABc]=4;f=X1b(d);d.c.appendChild(f);fe(b);Ydc(d.k,b);f.appendChild(b.N);he(b,d);if(c){e=new TZb('\u0645\u062E\u062A\u0627\u0631\u0629: 0, 0');$d(b,new FCb(b,e),(lp(),lp(),kp));$d(b,new JCb(b,e),(so(),so(),ro));g=X1b(d);d.c.appendChild(g);fe(e);Ydc(d.k,e);g.appendChild(e.N);he(e,d)}return d}
function Pab(){var b,c,d,e,f,g,i;while(Mab){b=Mab;Mab=Mab.c;!Mab&&(Nab=null);Thb(b.b.b,(i=new Tdc,i.f[ABc]=5,f=new _4b,qdc(f.N,zxc,'cwBasicText-textbox'),ht(f.b,(xH(),xH(),wH)),d=new _4b,qdc(d.N,zxc,'cwBasicText-textbox-disabled'),d.N[kDc]=WHc,gt(d.b),d.N[gDc]=true,Rdc(i,new YZb('<b>\u0645\u0631\u0628\u0639 \u0646\u0635 \u0639\u0627\u062F\u064A:<\/b>')),Rdc(i,wCb(f,true)),Rdc(i,wCb(d,false)),e=new b5b,qdc(e.N,zxc,'cwBasicText-password'),c=new b5b,qdc(c.N,zxc,'cwBasicText-password-disabled'),c.N[kDc]=WHc,gt(c.b),c.N[gDc]=true,Rdc(i,new YZb('<br><br><b>\u0645\u0631\u0628\u0639 \u0646\u0635 \u0643\u0644\u0645\u0629 \u0627\u0644\u0633\u0631:<\/b>')),Rdc(i,wCb(e,true)),Rdc(i,wCb(c,false)),g=new Abc,qdc(g.N,zxc,'cwBasicText-textarea'),g.N.rows=5,Rdc(i,new YZb('<br><br><b>\u0645\u0646\u0637\u0642\u0629 \u0627\u0644\u0646\u0635:<\/b>')),Rdc(i,wCb(g,true)),i))}}
var XHc='runCallbacks38',WHc='\u0642\u0631\u0627\u0621\u0629 \u0641\u0642\u0637';_=yH.prototype=tH.prototype=new uH;_.Cd=function zH(b){return KH.test((TH(),b))?($w(),Zw):($w(),Yw)};_.gC=function AH(){return pM};_.cM={};var wH;_=Qab.prototype=Lab.prototype=new Z;_.gC=function Rab(){return eO};_.Dd=function Vab(){Pab()};_.cM={};_=FCb.prototype=ECb.prototype=new Z;_.gC=function GCb(){return iT};_.lc=function HCb(b){xCb(this.c,this.b)};_.cM={30:1,140:1};_.b=null;_.c=null;_=JCb.prototype=ICb.prototype=new Z;_.gC=function KCb(){return jT};_.jc=function LCb(b){xCb(this.c,this.b)};_.cM={25:1,140:1};_.b=null;_.c=null;_=O4b.prototype;_.pf=function U4b(){return jfc(this.N)};_.qf=function V4b(){return kfc(this.N)};_=b5b.prototype=L4b.prototype=new M4b;_.gC=function c5b(){return iX};_.cM={13:1,14:1,15:1,16:1,69:1,71:1};_=zbc.prototype;_.pf=function Cbc(){return jfc(this.N)};_.qf=function Dbc(){return kfc(this.N)};var pM=ulc(vCc,'AnyRtlDirectionEstimator'),eO=ulc(wCc,'AsyncLoader38'),iT=ulc(ICc,'CwBasicText$2'),jT=ulc(ICc,'CwBasicText$3'),iX=ulc(fCc,'PasswordTextBox');sxc(Sab)();