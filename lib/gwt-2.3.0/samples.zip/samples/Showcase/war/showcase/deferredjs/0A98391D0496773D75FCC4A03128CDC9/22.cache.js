function I5(){}
function D5(){}
function fzb(){}
function jzb(){}
function nzb(){}
function gzb(b){this.b=b}
function kzb(b){this.b=b}
function rzb(b){this.b=b}
function czb(b){hib(b.c,Zyb(b.b))}
function H5(){var b;while(E5){b=E5;E5=E5.c;!E5&&(F5=null);czb(b.b)}}
function ozb(b){pzb(b,(1+Math.cos(6.283185307179586))/2);b.b.j.N[yDc]=!true;b.b.i.N[yDc]=!false}
function K5(){G5=new I5;ci((ai(),_h),22);!!$stats&&$stats(Ji(sHc,Vxc,-1,-1));G5.Hd();!!$stats&&$stats(Ji(sHc,lDc,-1,-1))}
function pzb(b,c){var d;d=6.283185307179586*c;qzb(b,b.b.d,d,0);qzb(b,b.b.c,d,1.5707963267948966);qzb(b,b.b.e,d,3.141592653589793);qzb(b,b.b.f,d,4.71238898038469)}
function qzb(b,c,d,e){var f,g;d+=e;f=100*Math.cos(d)+120;g=100*Math.sin(d)+120;eWb(b.b.b,c,~~Math.max(Math.min(f,2147483647),-2147483648),~~Math.max(Math.min(g,2147483647),-2147483648))}
function Zyb(b){var c,d,e,f,g,i;b.b=new gWb;Id(b.b,tHc,tHc);b.b.ub(uHc);b.f=new xSb((okb(),ckb));b.c=new xSb(ckb);b.d=new xSb(ckb);b.e=new xSb(ckb);$Vb(b.b,b.f);$Vb(b.b,b.c);$Vb(b.b,b.d);$Vb(b.b,b.e);c=new wZb;ze(c,b.b);e=new wZb;ze(e,(f=new fec,f.f[SBc]=5,f.b=(Z1b(),T1b),dec(f,new l$b('<b>\u062E\u064A\u0627\u0631\u0627\u062A \u0627\u0644\u0631\u0633\u0648\u0645 \u0627\u0644\u0645\u062A\u062D\u0631\u0643\u0629<\/b>')),b.j=new XWb('\u0627\u0644\u0628\u062F\u0621'),Ud(b.j.tb(),vHc,true),$d(b.j,new gzb(b),(Do(),Do(),Co)),dec(f,b.j),b.i=new XWb('\u0625\u0644\u063A\u0627\u0621'),Ud(b.i.tb(),vHc,true),$d(b.i,new kzb(b),Co),dec(f,b.i),f));d=new o2b;d.f[SBc]=10;g=m2b(d);d.c.appendChild(g);fe(e);kec(d.k,e);g.appendChild(e.N);he(e,d);i=m2b(d);d.c.appendChild(i);fe(c);kec(d.k,c);i.appendChild(c.N);he(c,d);b.g=new rzb(b);ozb(b.g);return d}
var sHc='runCallbacks22';_=I5.prototype=D5.prototype=new Z;_.gC=function J5(){return xN};_.Hd=function N5(){H5()};_.cM={};_=gzb.prototype=fzb.prototype=new Z;_.gC=function hzb(){return DS};_.nc=function izb(b){gb(this.b.g,2000,(new Date).getTime())};_.cM={25:1,140:1};_.b=null;_=kzb.prototype=jzb.prototype=new Z;_.gC=function lzb(){return ES};_.nc=function mzb(b){fb(this.b.g)};_.cM={25:1,140:1};_.b=null;_=rzb.prototype=nzb.prototype=new Y;_.gC=function szb(){return FS};_.$=function tzb(){ozb(this)};_._=function uzb(){var b;b=6.283185307179586*((1+Math.cos(3.141592653589793))/2);qzb(this,this.b.d,b,0);qzb(this,this.b.c,b,1.5707963267948966);qzb(this,this.b.e,b,3.141592653589793);qzb(this,this.b.f,b,4.71238898038469);this.b.j.N[yDc]=!false;this.b.i.N[yDc]=!true};_.ab=function vzb(b){pzb(this,b)};_.cM={52:1};_.b=null;var xN=Mlc(OCc,'AsyncLoader22'),DS=Mlc(WCc,'CwAnimation$2'),ES=Mlc(WCc,'CwAnimation$3'),FS=Mlc(WCc,'CwAnimation$CustomAnimation');Kxc(K5)();