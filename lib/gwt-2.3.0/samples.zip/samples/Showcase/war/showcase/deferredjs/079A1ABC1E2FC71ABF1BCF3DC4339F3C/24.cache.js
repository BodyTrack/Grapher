function Z5(){}
function X5(){}
function _5(){Y5=new Z5;di((bi(),ai),24);!!$stats&&$stats(Ki(fHc,Dxc,-1,-1));Y5.Dd();!!$stats&&$stats(Ki(fHc,VCc,-1,-1))}
var fHc='runCallbacks24';_=Z5.prototype=X5.prototype=new Z;_.gC=function $5(){return nN};_.Dd=function a6(){};_.cM={};var Y5=null;var nN=ulc(wCc,'AsyncLoader24');sxc(_5)();